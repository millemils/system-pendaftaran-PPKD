-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: pelatihan
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (5,'2014_10_12_000000_create_users_table',1),(6,'2014_10_12_100000_create_password_resets_table',1),(7,'2019_08_19_000000_create_failed_jobs_table',1),(8,'2019_12_14_000001_create_personal_access_tokens_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pelatihan`
--

DROP TABLE IF EXISTS `pelatihan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pelatihan` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `kode_pelatihan` varchar(45) NOT NULL,
  `nama_pelatihan` text NOT NULL,
  `deskripsi` text NOT NULL,
  `photo` text,
  `tanggal_pendaftaran_mulai` date DEFAULT NULL,
  `tanggal_pendaftaran_selesai` date DEFAULT NULL,
  `tanggal_pelatihan_mulai` datetime DEFAULT NULL,
  `tanggal_pelatihan_selesai` datetime DEFAULT NULL,
  `lokasi` text NOT NULL,
  `jurusan` text NOT NULL,
  `minimal_score_psikotest` int DEFAULT NULL,
  `minimal_score_buta_warna` int DEFAULT NULL,
  `syarat_ketentuan` text NOT NULL,
  `kuota` int NOT NULL,
  `biaya` decimal(24,2) DEFAULT NULL,
  `methode` text,
  `alur_seleksi` text,
  `level` varchar(45) DEFAULT NULL,
  `sertifikat` text,
  `status` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pelatihan`
--

LOCK TABLES `pelatihan` WRITE;
/*!40000 ALTER TABLE `pelatihan` DISABLE KEYS */;
INSERT INTO `pelatihan` VALUES (1,'hScFe-17/August/2023','testing pelatihan','testing','public/files/PWgzTz57O1wNn3Q4edXLFAR7Vw49v4eNa5BjxBb5.jpg','2023-08-17','2023-08-17','2023-08-17 00:00:00','2023-08-17 00:00:00','Online','Informatika',NULL,NULL,'testing akmal',150,120000.00,NULL,NULL,NULL,NULL,'Selesai','2023-08-16 23:04:53','2023-08-17 20:42:55'),(2,'0XfPX-17/August/2023','testing kedua','testing kedua','public/files/1IV3UgIv0QQcEE40lzaAKmZm1O1VsSxuP7KNLc2h.png','2023-08-18','2023-08-18','2023-08-18 00:00:00','2023-08-18 00:00:00','Online','Teknik Industri',50,50,'testing kedua',200,150000.00,NULL,NULL,NULL,NULL,'New','2023-08-16 23:10:34','2023-08-16 23:10:34'),(4,'2Fc3I-17/August/2023','testing email','testing email','public/files/ldSRu7g5XmcgzwEesa2vUDT8JGyX1idKYtKynR7j.png','2023-08-18','2023-08-21','2023-08-22 11:00:00','2023-08-25 15:00:00','Online','Informatika',10,10,'testing email',200,170000.00,NULL,NULL,NULL,NULL,'New','2023-08-17 08:03:28','2023-08-17 21:12:30'),(5,'c6qP4-18/August/2023','testing akmal new','testing akmal pelatihan laravel sederhana dengan template admin dan bootstrap, pembuatan aplikasi web, setup database dan lainnya','public/files/wvc9MCsuME3a7M539deaGlPimNbcRTRkoOAX5AWJ.png','2023-08-18','2023-08-18','2023-08-18 22:37:00','2023-08-21 22:37:00','Online','Informatika',20,20,'Pelatihan ini dikhususkan untuk peserta yang memiliki leptop dan sudah paham penggunaan framework laravel.',20,0.00,'Normal','alur normal','Intermediete','Non Certificate','New','2023-08-18 08:38:42','2023-08-22 02:23:30'),(6,'tUSe6-23/August/2023','Membuat Website Sederhana Dengan Laravel','Membuat Website Sederhana dengan Laravel adalah panduan praktis bagi mereka yang ingin memulai perjalanan mereka dalam pengembangan web. Dalam proyek ini, Anda akan belajar bagaimana membangun website sederhana dengan fitur dasar seperti halaman beranda, halaman kontak, dan formulir kontak. Anda akan dibimbing melalui langkah-langkah mulai dari persiapan awal hingga penyelesaian proyek, dengan fokus pada penggunaan Laravel untuk mengatur rute, tampilan, dan formulir.','public/files/gGceibykaZ1Ly8Mb1OrGrvclYA95gMEivgkbB8qU.webp','2023-08-23','2023-08-23','2023-08-23 16:43:00','2023-08-24 16:44:00','Gedung Gajah, Tebet Raharjo','Informatika',50,50,'<p>Selamat datang dalam pelatihan &quot;Membuat Website Sederhana dengan Laravel&quot;. Sebelum Anda memulai kursus ini, harap perhatikan syarat dan ketentuan yang kami tetapkan untuk memastikan pengalaman belajar yang optimal dan lingkungan yang aman bagi semua peserta.</p>\r\n\r\n<p><strong>1. Kewajiban Peserta:</strong></p>\r\n\r\n<ul>\r\n	<li>Peserta diharapkan memiliki pemahaman dasar tentang HTML, CSS, dan konsep dasar pemrograman web.</li>\r\n	<li>Keterampilan dasar dalam bahasa pemrograman PHP dan pengetahuan tentang basis data akan menjadi nilai tambah.</li>\r\n	<li>Peserta diharapkan memiliki laptop atau perangkat yang dapat diakses selama pelatihan, serta koneksi internet yang stabil.</li>\r\n</ul>\r\n\r\n<p><strong>2. Keharusan Etika:</strong></p>\r\n\r\n<ul>\r\n	<li>Peserta diharapkan untuk berperilaku dengan sopan dan menghormati pendidik, rekan peserta, dan staf pendukung pelatihan.</li>\r\n	<li>Tidak diperkenankan melakukan plagiarisme atau menggunakan materi yang bukan hasil karya sendiri tanpa izin.</li>\r\n	<li>Tidak diperkenankan untuk mengganggu jalannya sesi pelatihan atau mengirimkan konten tidak pantas dalam platform komunikasi yang disediakan.</li>\r\n</ul>\r\n\r\n<p><strong>3. Materi dan Sumber Daya:</strong></p>\r\n\r\n<ul>\r\n	<li>Materi yang diajarkan dalam pelatihan adalah hak cipta dan hanya boleh digunakan untuk tujuan pembelajaran. Tidak diperkenankan menyebarkan materi ini tanpa izin tertulis.</li>\r\n	<li>Setiap materi yang disediakan adalah panduan pembelajaran, dan Anda dianjurkan untuk melakukan eksperimen dan eksplorasi lebih lanjut untuk memperdalam pemahaman Anda.</li>\r\n</ul>\r\n\r\n<p><strong>4. Pendaftaran dan Pembayaran:</strong></p>\r\n\r\n<ul>\r\n	<li>Pendaftaran ke pelatihan harus dilakukan sesuai dengan petunjuk yang diberikan oleh penyelenggara.</li>\r\n	<li>Pembayaran yang telah dilakukan bersifat final dan tidak dapat dikembalikan, kecuali jika acara dibatalkan oleh penyelenggara.</li>\r\n</ul>\r\n\r\n<p><strong>5. Tanggung Jawab Pelatihan:</strong></p>\r\n\r\n<ul>\r\n	<li>Penyelenggara berhak mengubah jadwal, materi, atau pengajar jika diperlukan. Peserta akan diberi informasi sebelumnya jika ada perubahan signifikan.</li>\r\n	<li>Penyelenggara berusaha memberikan materi dan dukungan yang berkualitas, namun tidak bertanggung jawab atas hasil belajar individu peserta.</li>\r\n</ul>\r\n\r\n<p><strong>6. Perlindungan Privasi:</strong></p>\r\n\r\n<ul>\r\n	<li>Data pribadi yang diberikan oleh peserta hanya akan digunakan untuk keperluan pelatihan dan tidak akan disebarkan atau dijual kepada pihak ketiga.</li>\r\n</ul>\r\n\r\n<p><strong>7. Penutupan Pelatihan:</strong></p>\r\n\r\n<ul>\r\n	<li>Penyelenggara berhak menutup pelatihan pada akhir periode yang ditentukan, dan tidak ada hak untuk akses lanjutan ke materi setelah penutupan.</li>\r\n</ul>\r\n\r\n<p>Dengan menerima syarat dan ketentuan ini, Anda setuju untuk mengikuti pedoman yang telah ditetapkan oleh pelatihan &quot;Membuat Website Sederhana dengan Laravel&quot;. Semoga pelatihan ini memberikan manfaat dan pengetahuan baru bagi Anda dalam mengembangkan keterampilan pengembangan web. Jika Anda memiliki pertanyaan atau kekhawatiran, jangan ragu untuk menghubungi tim pendukung kami. Selamat belajar!</p>',200,0.00,'Coding','Normal','Intermediete','Non Certificate','New','2023-08-23 02:47:09','2023-08-23 02:58:00');
/*!40000 ALTER TABLE `pelatihan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pelatihan_daftar`
--

DROP TABLE IF EXISTS `pelatihan_daftar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pelatihan_daftar` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `pelatihan_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `tanggal_daftar` datetime DEFAULT NULL,
  `tanggal_bayar` datetime DEFAULT NULL,
  `bukti_bayar` text,
  `status` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pelatihan_daftar`
--

LOCK TABLES `pelatihan_daftar` WRITE;
/*!40000 ALTER TABLE `pelatihan_daftar` DISABLE KEYS */;
INSERT INTO `pelatihan_daftar` VALUES (1,4,2,'2023-08-18 15:04:26','2023-08-21 16:23:41','public/files/ovzBEnM9Co1S7RxXV78YN0HMn53H2KI6YxCnmTFf.png','Menunggu Konfirmasi','2023-08-18 08:04:26','2023-08-21 09:23:41'),(2,5,2,'2023-08-21 10:44:44','2023-08-23 08:05:06','public/files/egKnAKvAvJZZdFkGCJMX8V0R3W0kjcAEuGQULlq9.pdf','Menunggu Konfirmasi','2023-08-21 03:44:44','2023-08-23 01:05:06');
/*!40000 ALTER TABLE `pelatihan_daftar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profile` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `photo` text,
  `jurusan` text,
  `alamat` text,
  `nik` text,
  `tanggal_lahir` date DEFAULT NULL,
  `psikotest_score` bigint DEFAULT NULL,
  `buta_warna_score` bigint DEFAULT NULL,
  `psikotest_status` varchar(45) DEFAULT NULL,
  `buta_warna_status` varchar(45) DEFAULT NULL,
  `nama_lengkap` text,
  `jenis_kelamin` varchar(45) DEFAULT NULL,
  `tempat_lahir` varchar(45) DEFAULT NULL,
  `pendidikan_terakhir` varchar(45) DEFAULT NULL,
  `wa_pribadi` varchar(45) DEFAULT NULL,
  `wa_kerabat` varchar(45) DEFAULT NULL,
  `sekolah_asal` varchar(255) DEFAULT NULL,
  `sumber_info_pelatihan` text,
  `keterbatasan_fisik` text,
  `ktp` text,
  `vaksin` text,
  `tujuan_ikut_pelatihan` text,
  `sumber_info_ppkd` text,
  `sudah_ikut_pelatihan` text,
  `siap_ikut_pelatihan` text,
  `usulan_pelatihan` text,
  `pesan_untuk_ppkd` text,
  `status_pekerjaan` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (1,2,'public/files/EhTXloM457fkoWlX3mi3DMXN3wLmk5WxdK1oDHn6.jpg','Manajemen Informatika','JL S Memberamo Blok F 87 RT 007 RW 019, Kelurahan Harapan Jaya, Kecamata Bekasi Utara, Kota Bekasi, 17124','123456','1996-05-30',67,67,'Open','Open','Muhammad Shulhan Akmal','Laki-Laki','Bekasi','D3','081770825253','0218866787','Bina Sarana Informatika','Iklan Online','-','public/files/k5wsfjGSV2NKS6bEH8vbx3taRW1CqE4VD6AAURyW.jpg','public/files/TzDwhxuLdbmqzPKl2FCMdqvQp3yJTUFCvONQkMvr.pdf','tujuan saya mengikuti pelatihan adalah untuk menambah wawasan saya dalam segala bidang','Saya mengetahui informasi tentang PPKD dari situs online','Saya belum pernah mengikuti pelatihan','Saya siap mengikuti pelatihan dan tata tertib pelatihan','Saya berharap ada lebih banyak lagi pelatihan yang berkaitan dalam bidang informatika dan coding','Saya berharap kedepannya PPKD jakarta selatan lebih banyak lagi mengadakan pelatihan khususnya pelatihan di bidang technology','IT','2023-08-15 08:36:01','2023-08-23 04:24:31'),(2,1,'public/files/ugbBObQ7mIX2G1iUVMTwsxxW3hhQ30Roq6MhRFg6.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'Open','Open',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-08-16 09:31:41','2023-08-16 09:31:41');
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psikotest`
--

DROP TABLE IF EXISTS `psikotest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `psikotest` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `flag` varchar(45) NOT NULL,
  `pertanyaan` text NOT NULL,
  `image` text,
  `option_a` text NOT NULL,
  `option_b` text NOT NULL,
  `option_c` text NOT NULL,
  `option_d` text NOT NULL,
  `nomor_urut` bigint NOT NULL,
  `jawaban` text NOT NULL,
  `status` varchar(45) DEFAULT NULL,
  `img_a` text,
  `img_b` text,
  `img_c` text,
  `img_d` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psikotest`
--

LOCK TABLES `psikotest` WRITE;
/*!40000 ALTER TABLE `psikotest` DISABLE KEYS */;
INSERT INTO `psikotest` VALUES (1,'Psikotest','1+1',NULL,'10','2','11','1',1,'B','Active',NULL,NULL,NULL,NULL,'2023-08-15 08:29:16','2023-08-15 08:29:16'),(2,'Psikotest','2+2',NULL,'2','22','20','4',2,'D','Active',NULL,NULL,NULL,NULL,'2023-08-15 08:29:47','2023-08-15 08:30:53'),(3,'Psikotest','3+3',NULL,'3','6','33','30',3,'B','Active',NULL,NULL,NULL,NULL,'2023-08-15 08:30:33','2023-08-15 08:30:53'),(4,'Buta Warna','test buta warna nomor 1','public/files/Rv1sg3msYxjfLCFIWcat9orc7Tn3T4aGcaas2rsF.jpg','merah','biru','kunging','hijau',1,'A','Active',NULL,NULL,NULL,NULL,'2023-08-15 08:31:47','2023-08-15 08:31:47'),(5,'Buta Warna','warna dominan pada warna berikut','public/files/Y5RZxBHr5iibiZYmFAKwHeA2vU0UJ18CHz8N1IAE.png','putih','merah','kuning','biru',2,'A','Active','public/files/4Xc6aIYnQ09BapNANuABjvVeIAZClcjV6W9F1ztD.png','public/files/fLAszVGGjdv7o9A2lZjcWpSpmTlJsO1HCEyQKQgK.jpg','public/files/HVL6AeJOvQdow9dgDBek50uLFYSIyneVKnQRiHYd.jpg','public/files/DlQhUpz3Ogb9gA5GbsCPC7Yelp1AOJQeKa9HoiXQ.png','2023-08-15 08:32:45','2023-08-15 08:32:45');
/*!40000 ALTER TABLE `psikotest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'PPKD','Admin','admin@pelatihan.com',NULL,'$2y$10$Xz3DYqmCTFTmt9hdq1fkoO6Qtxfqi86sp7FPxYsocTGFzcbp1e/ea','Admin','Active',NULL,'2023-08-08 09:18:25','2023-08-16 09:57:39'),(2,'Shulhan','Akmal','shulhanakmal1996@gmail.com',NULL,'$2y$10$GWV4UC8OEL.zFtFYfvzTLeupaFoTJnpkJk2h1psAqY9jFHB6H5rEC','Peserta','Active',NULL,'2023-08-13 01:21:06','2023-08-16 08:34:47');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-23 21:20:35
