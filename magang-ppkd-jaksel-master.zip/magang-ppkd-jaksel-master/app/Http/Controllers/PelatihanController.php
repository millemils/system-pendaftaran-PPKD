<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\User;
use App\Models\Pelatihan;
use Illuminate\Http\Request;
use App\Mail\NotifikasiAdmin;
use App\Mail\NotifikasiPeserta;
use App\Models\PelatihanDaftar;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Auth;

class PelatihanController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth'); // authentication
    }


    public function index(){

        // mendapatkan nilai rata-rata psikotest dan buta warna
        $averageScores = DB::table('profile')
            ->selectRaw('AVG(psikotest_score) as avg_score_psikotest, AVG(buta_warna_score) as avg_score_buta_warna')
            ->first();
        $avgPsikotest = $averageScores->avg_score_psikotest;
        $avgButaWarna = $averageScores->avg_score_buta_warna;

        // mendapatkan tanggal sekarang
        $currentDate = Carbon::now();

        //  mendapatkan data pelatihan yang kurang dari atau samadengan tanggal sekarang
        $pelatihan = Pelatihan::where('status', '!=', 'Selesai')->get();
        $allPelatihan = Pelatihan::get();

        $compact = compact(
            'pelatihan',
            'avgPsikotest',
            'avgButaWarna',
            'allPelatihan'
        );

        return view('admin.pelatihan', $compact);

    }

    public function pelatihanAdd() {

        return view('admin.pelatihanAdd');

    }

    public function pelatihanAddPost(Request $request){

        // generate random string
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';
        for ($i = 0; $i < 5; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }

        // get current date
        $currentDate = date('d/F/Y');

        // combine string and date
        $code = $randomString . '-' . $currentDate;

        // Hapus karakter non-numeric dan simbol mata uang
        $rupiahBiaya = preg_replace("/[^0-9]/", "", $request->biaya);

        // Konversi ke tipe data numerik (float)
        $biaya = (float) $rupiahBiaya;


        // insert data
        $insert = new Pelatihan;
        $insert->kode_pelatihan = $code;
        $insert->nama_pelatihan = $request->nama_pelatihan;
        $insert->deskripsi = $request->deskripsi;
        if($request->hasFile('photo')){
            $insert->photo = $request->file('photo')->store('public/files');
        }
        if($request->tanggal_pendaftaran_mulai) {
            $insert->tanggal_pendaftaran_mulai = $request->tanggal_pendaftaran_mulai;
        }
        if($request->tanggal_pendaftaran_selesai) {
            $insert->tanggal_pendaftaran_selesai = $request->tanggal_pendaftaran_selesai;
        }
        if($request->tanggal_pelatihan_mulai) {
            $insert->tanggal_pelatihan_mulai = $request->tanggal_pelatihan_mulai;
        }
        if($request->tanggal_pelatihan_selesai) {
            $insert->tanggal_pelatihan_selesai = $request->tanggal_pelatihan_selesai;
        }
        $insert->lokasi = $request->lokasi;
        $insert->jurusan = $request->jurusan;
        if($request->min_score_psikotest) {
            $insert->minimal_score_psikotest = $request->min_score_psikotest;
        }
        if($request->min_score_buta_warna) {
            $insert->minimal_score_buta_warna = $request->min_score_buta_warna;
        }
        if($request->methode) {
            $insert->methode = $request->methode;
        }
        if($request->alur_seleksi) {
            $insert->alur_seleksi = $request->alur_seleksi;
        }
        if($request->level) {
            $insert->level = $request->level;
        }
        if($request->sertifikat) {
            $insert->sertifikat = $request->sertifikat;
        }
        $insert->syarat_ketentuan = $request->syarat_ketentuan;
        $insert->kuota = $request->kuota;
        // $insert->biaya = $biaya;
        $insert->status = 'New';
        $insert->save();

        return redirect()->route('pelatihan')->with('message', 'Pelatihan berhasil dibuat');

    }

    public function pelatihanHapus($pelatihanId){

        $hapus = Pelatihan::find($pelatihanId);
        $hapus->delete();

        return redirect()->back()->with('message', 'Pelatihan berhasil dihapus');

    }

    public function pelatihanDetail($pelatihanId) {

        $pelatihan = Pelatihan::find($pelatihanId);
        $daftarPeserta = PelatihanDaftar::where('pelatihan_id', $pelatihanId)->get();

        $compact = compact(
            'pelatihan',
            'daftarPeserta'
        );

        return view('peserta.detilPelatihan', $compact);

    }

    public function listPelatihan() {

        // get data pelatihan yang belum selesai
        $pelatihan = Pelatihan::where('status', '!=', 'Selesai')->get();

        // get data jurusan pelatihan
        $jurusan = Pelatihan::select('jurusan')->distinct()->get();

        $compact = compact(
            'pelatihan',
            'jurusan'
        );

        return view('peserta.pelatihan', $compact);

    }

    public function detailPelatihan($pelatihanId) {

        $pelatihan = Pelatihan::find($pelatihanId);
        $daftarPeserta = PelatihanDaftar::where('pelatihan_id', $pelatihanId)->get();

        $compact = compact(
            'pelatihan',
            'daftarPeserta'
        );

        return view('peserta.detilPelatihan', $compact);

    }

    public function daftarPelatihan($pelatihanId){

        // get data user
        $user = Auth::user();

        // get data pelatihan
        $pelatihan = Pelatihan::find($pelatihanId);

        // get data pelatihan yang sudah terdaftar
        // $listPeserta = PelatihanDaftar::where('pelatihan_id', $pelatihanId)->where('status', 'Terdaftar')->get();
        $listPeserta = PelatihanDaftar::where('pelatihan_id', $pelatihanId)
        ->where(function($query) {
            $query->where('status', 'Terdaftar')
                ->orWhere('status', 'Menunggu Konfirmasi');
        })->get();

        // jika kuota pelatihan lebih besar atau sama dengan jumlah list peserta maka proses lanjut (peserta masih bisa daftar)
        if($pelatihan->kuota >= count($listPeserta)) {

            // check nilai apakah cukup
            if($pelatihan->minimal_score_psikotest <= $user->profile->psikotest_score && $pelatihan->minimal_score_buta_warna <= $user->profile->buta_warna_score) {

                // insert data ke table pelatihan_daftar
                $insert = new PelatihanDaftar;
                $insert->pelatihan_id = $pelatihanId;
                $insert->user_id = Auth::user()->id;
                $insert->tanggal_daftar = Carbon::now();
                $insert->status = 'Menunggu Surat';
                $insert->save();

                return redirect()->back()->with('message', 'Berhasil daftar, silahkan upload bukti surat');

            } else {

                $messages = [
                    'required' => 'Score test anda tidak cukup untuk mengikuti pelatihan',
                ];
                return redirect()->back()->withErrors($messages)->with('error', $messages);

            }

        } else {

            $messages = [
                'required' => 'Kuota pelatihan sudah penuh, silahkan ikuti pelatihan yang lain',
            ];
            return redirect()->back()->withErrors($messages)->with('error', $messages);

        }

    }

    public function daftarPelatihanBayar(Request $request, $pelatihanId) {

        // get user
        $user = Auth::user();

        // data pelatihan
        $pelatihan = Pelatihan::find($pelatihanId);

        // get email admin
        $Admin = User::where('role', 'Admin')->first();

        // cari data di table pelatihan_daftar
        $transaksi = PelatihanDaftar::where('pelatihan_id', $pelatihanId)->where('user_id', $user->id)->first();
        if($request->hasFile('bukti_bayar')) {

            // simpan data
            $transaksi->bukti_bayar = $request->file('bukti_bayar')->store('public/files');
            $transaksi->status = 'Menunggu Konfirmasi';
            $transaksi->tanggal_bayar = Carbon::now();
            $transaksi->save();

            // get data untuk konten email
            $data = [
                'pelatihan' => $pelatihan,
                'transaksi' => $transaksi,
                'user' => $user
            ];

            // kirim email
            Mail::to($Admin->email)->send(new NotifikasiAdmin($data));

            return redirect()->route('dashboard')->with('message', 'Berhasil bayar, silahkan mengikuti pelatihan');
        } else {

            $messages = [
                'required' => 'Harap upload surat motivasi',
            ];
            return redirect()->back()->withErrors($messages)->with('error', $messages);

        }

    }

    public function decisionDaftar($pelatihanDaftarId, $decision) {

        // get data pelatihan daftar
        $data = PelatihanDaftar::find($pelatihanDaftarId);

        if($decision == 'approve') {
            $data->status = 'Terdaftar';
            $data->save();

            // get data untuk konten email
            $dataEmail = [
                'pelatihan' => $data->getPelatihan,
                'decision' => 'DAPPROVE',
                'redaksi' => 'Silahkan untuk mengikuti pelatihan '.$data->getPelatihan->nama_pelatihan
            ];

            // kirim email
            Mail::to($data->getUser->email)->send(new NotifikasiPeserta($dataEmail));

            return redirect()->route('dashboard')->with('message', 'Data berhasil diproses');

        } elseif($decision == 'reject') {
            $data->status = 'Ditolak';
            $data->save();

            // get data untuk konten email
            $dataEmail = [
                'pelatihan' => $pelatihan,
                'decision' => 'DIREJECT',
                'redaksi' => 'Pastikan anda tidak melakukan salah upload surat. Silahkan hubungi admin di nomor 081770825253 untuk penanganan lebih lanjut.'
            ];

            // kirim email
            Mail::to($data->getUser->email)->send(new NotifikasiPeserta($dataEmail));

            return redirect()->route('dashboard')->with('message', 'Data berhasil diproses');

        } else {
            $messages = [
                'required' => 'Proses salah, terjadi error kesalahan proses',
            ];
            return redirect()->back()->withErrors($messages)->with('error', $messages);
        }

    }

    public function pelatihanEdit($pelatihanId) {

        $pelatihan = Pelatihan::find($pelatihanId);
        $daftarPeserta = PelatihanDaftar::where('pelatihan_id', $pelatihanId)->get();

        $compact = compact(
            'pelatihan',
            'daftarPeserta'
        );

        return view('admin.pelatihanEdit', $compact);

    }

    public function pelatihanEditPost(Request $request) {

        // Hapus karakter non-numeric dan simbol mata uang
        $rupiahBiaya = preg_replace("/[^0-9]/", "", $request->biaya);

        // Konversi ke tipe data numerik (float)
        $biaya = (float) $rupiahBiaya;

        // update data
        $insert = Pelatihan::find($request->pelatihan_id);
        $insert->nama_pelatihan = $request->nama_pelatihan;
        $insert->deskripsi = $request->deskripsi;
        if($request->hasFile('photo')){
            $insert->photo = $request->file('photo')->store('public/files');
        }
        if($request->tanggal_pendaftaran_mulai) {
            $insert->tanggal_pendaftaran_mulai = $request->tanggal_pendaftaran_mulai;
        }
        if($request->tanggal_pendaftaran_selesai) {
            $insert->tanggal_pendaftaran_selesai = $request->tanggal_pendaftaran_selesai;
        }
        if($request->tanggal_pelatihan_mulai) {
            $insert->tanggal_pelatihan_mulai = $request->tanggal_pelatihan_mulai;
        }
        if($request->tanggal_pelatihan_selesai) {
            $insert->tanggal_pelatihan_selesai = $request->tanggal_pelatihan_selesai;
        }
        $insert->lokasi = $request->lokasi;
        $insert->jurusan = $request->jurusan;
        if($request->min_score_psikotest) {
            $insert->minimal_score_psikotest = $request->min_score_psikotest;
        }
        if($request->min_score_buta_warna) {
            $insert->minimal_score_buta_warna = $request->min_score_buta_warna;
        }
        if($request->methode) {
            $insert->methode = $request->methode;
        }
        if($request->alur_seleksi) {
            $insert->alur_seleksi = $request->alur_seleksi;
        }
        if($request->level) {
            $insert->level = $request->level;
        }
        if($request->sertifikat) {
            $insert->sertifikat = $request->sertifikat;
        }
        $insert->syarat_ketentuan = $request->syarat_ketentuan;
        $insert->kuota = $request->kuota;
        $insert->biaya = $biaya;
        $insert->status = 'New';
        $insert->save();

        return redirect()->route('pelatihan')->with('message', 'Pelatihan berhasil dibuat');

    }

    public function selesai($pelatihanId) {

        $pelatihan = Pelatihan::find($pelatihanId);
        $pelatihan->status = 'Selesai';
        $pelatihan->save();

        return redirect()->back()->with('message', 'Data berhasil disimpan, Pelatihan telah selesai');
        
    }
    
}
