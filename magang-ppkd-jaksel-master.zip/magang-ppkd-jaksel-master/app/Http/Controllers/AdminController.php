<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Pelatihan;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Models\PelatihanDaftar;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth'); // authentication
    }

    public function index() {

        $user = Auth::user();

        if($user->role == 'Admin') {

            // olah data untuk login admin

            // get data pelatihan yang butuh konfirmasi
            $konfirmasiPelatihan = PelatihanDaftar::where('status', 'Menunggu Konfirmasi')->orderBy('created_at', 'desc')->get();

            // get data total pelatihan
            $totalPelatihan = Pelatihan::orderBy('created_at', 'desc')->get();

            // get data total peserta
            $totalPeserta = User::where('role', 'Peserta')->get();

            // get pelatihan pada hari ini
            $currentDate = Carbon::now(); // Tanggal dan waktu saat ini

            // get ongoing pelatihan
            $ongoingPelatihan = Pelatihan::whereBetween('tanggal_pelatihan_mulai', [$currentDate, $currentDate->copy()->endOfDay()])->orWhereBetween('tanggal_pelatihan_selesai', [$currentDate, $currentDate->copy()->endOfDay()])->get();


            // get data total dana
            // $totalDana = DB::table('pelatihan_daftar')
            // ->join('pelatihan', 'pelatihan_daftar.pelatihan_id', '=', 'pelatihan.id')
            // ->where('pelatihan_daftar.status', 'Terdaftar')
            // ->sum('pelatihan.biaya');

            // get data total pending request
            $pendingRequest = PelatihanDaftar::where('status', $user->id)->where('status', 'Menunggu Konfirmasi')->get();

            // mendapatkan data untuk pie chart
            $forPieLabels = ["Menunggu Surat", "Terdaftar", "Menunggu Konfirmasi", "Reject"];
            $forPieData = [
                count(PelatihanDaftar::where('status', 'Menunggu Surat')->get()),
                count(PelatihanDaftar::where('status', 'Terdaftar')->get()),
                count(PelatihanDaftar::where('status', 'Menunggu Konfirmasi')->get()),
                count(PelatihanDaftar::where('status', 'Reject')->get()),
            ];

            // mendapatkan data untuk line chart
            $forLineData = []; // Array untuk menyimpan data jumlah pelatihan

            // Loop untuk setiap bulan (1-12)
            for ($month = 1; $month <= 12; $month++) {
                // Menghitung jumlah pelatihan yang terdaftar atau menunggu konfirmasi
                $count = PelatihanDaftar::where(function($query) {
                        $query->where('status', 'Terdaftar')
                            ->orWhere('status', 'Menunggu Konfirmasi');
                    })
                    ->whereMonth('tanggal_daftar', $month)
                    ->count();

                $forLineData[] = $count;
            }

            $compact = compact(
                'user',
                'konfirmasiPelatihan',
                'totalPelatihan',
                'totalPeserta',
                // 'totalDana',
                'ongoingPelatihan',
                'pendingRequest',
                'forPieLabels',
                'forPieData',
                'forLineData'
            );

            return view('admin.dashboard', $compact);

        } else {

            // olah data untuk login peserta

            $pelatihanDiikuti = PelatihanDaftar::where('user_id', $user->id)
            ->where(function($query) {
                $query->where('status', 'Terdaftar')
                    ->orWhere('status', 'Menunggu Konfirmasi');
            })->get();

            $pelatihanTotal = PelatihanDaftar::where('user_id', $user->id)->orderBy('created_at', 'desc')->get();

            // mendapatkan data untuk pie chart
            $forPieLabels = ["Menunggu Surat", "Terdaftar", "Menunggu Konfirmasi", "Reject"];
            $forPieData = [
                count(PelatihanDaftar::where('user_id', $user->id)->where('status', 'Menunggu Surat')->get()),
                count(PelatihanDaftar::where('user_id', $user->id)->where('status', 'Terdaftar')->get()),
                count(PelatihanDaftar::where('user_id', $user->id)->where('status', 'Menunggu Konfirmasi')->get()),
                count(PelatihanDaftar::where('user_id', $user->id)->where('status', 'Reject')->get()),
            ];

            // mendapatkan data untuk line chart
            $forLineData = []; // Array untuk menyimpan data jumlah pelatihan

            // Loop untuk setiap bulan (1-12)
            for ($month = 1; $month <= 12; $month++) {
                // Menghitung jumlah pelatihan yang terdaftar atau menunggu konfirmasi
                $count = PelatihanDaftar::where('user_id', $user->id)
                    ->where(function($query) {
                        $query->where('status', 'Terdaftar')
                            ->orWhere('status', 'Menunggu Konfirmasi');
                    })
                    ->whereMonth('tanggal_daftar', $month)
                    ->count();

                $forLineData[] = $count;
            }

            $compact = compact(
                'user',
                'pelatihanTotal',
                'pelatihanDiikuti',
                'forPieLabels',
                'forPieData',
                'forLineData'
            );

            return view('peserta.dashboard', $compact);

        }


    }
}
