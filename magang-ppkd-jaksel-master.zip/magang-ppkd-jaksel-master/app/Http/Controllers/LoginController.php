<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{

    public function login() {

        return view('auth.login');

    }

    public function register() {

        return view('auth.register');

    }

    public function forgot() {

        return view('auth.forgotPassword');

    }

    public function registerPost(Request $request) {

        // check apakah user dengan email yang didaftarkan sudah terdaftar atau belum
        $cek = User::where('email', $request->email)->first();

        if(isset($cek)) { // jika email ditemukan

            // munculkan error
            return view('auth.login')->withErrors([
                'email' => 'Email telah terdaftar',
            ]);
            
        } else {

            // insert data ke database table user
            $insert = new User();
            $insert->first_name = $request->firstName;
            $insert->last_name = $request->lastName;
            $insert->email = $request->email;
            $insert->password = Hash::make($request->password);
            $insert->role = 'Peserta';
            $insert->status = 'Active';
            $insert->save();

            // menampilkan halaman login
            return view('auth.login')->with('success', 'akun berhasil dibuat');

        }

    }

    public function loginPost(Request $request) {

        $credentials = $request->only('email', 'password');

        $cek = User::where('email', $request->email)->first();

        if($cek){
            if($cek->status == 'Active'){
                if (!Hash::check($request->password, $cek->password)) { // jika passwordnya salah maka munculkan error
                    $messages = [
                        'required' => 'Password salah',
                    ];
                    return redirect()->back()->withErrors($messages)->with('error', $messages);
                } else {
                    if (Auth::attempt($credentials)) { // if success login
                        return redirect(route('dashboard'));
                    } else {
                        $messages = [
                            'required' => 'User tidak ditemukan',
                        ];
                        return redirect()->back()->withErrors($messages)->with('error', $messages);
                    }
                }
            } else {
                $messages = [
                    'required' => 'User ini telah dinonaktifkan',
                ];
                return redirect()->back()->withErrors($messages)->with('error', $messages);
            }
        } else {
            $messages = [
                'required' => 'User tidak ditemukan',
            ];
            return redirect()->back()->withErrors($messages)->with('error', $messages);
        }

    }

    public function logout(Request $request)
    {
        Auth::logout(); // Logout pengguna saat ini

        // Redirect pengguna ke halaman lain setelah logout
        return redirect('/login');
    }

}
