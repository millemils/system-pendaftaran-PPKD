<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class SettingController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth'); // authentication
    }

    public function index() {

        $user = Auth::user();

        $compact = compact(
            'user'
        );

        return view('setting', $compact);

    }

    public function post(Request $request) {

        $user = Auth::user();

        if (!Hash::check($request->password_lama, $user->password)) { // jika passwordnya salah maka munculkan error
            $messages = [
                'required' => 'Password yang anda inputkan pada password lama salah',
            ];
            return redirect()->back()->withErrors($messages)->with('error', $messages);
        } else {
            if($request->password_baru == $request->konfirmasi_password) {
                $update = User::find($user->id);
                $update->password = Hash::make($request->password_baru);
                $update->save();

                return redirect()->route('dashboard')->with('message', 'Password berhasil diupdate');
            } else {
                $messages = [
                    'required' => 'Konfirmasi password tidak sama',
                ];
                return redirect()->back()->withErrors($messages)->with('error', $messages);
            }
        }

    }
}
