<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Profile;
use App\Models\Pelatihan;
use App\Models\Psikotest;
use Illuminate\Http\Request;
use App\Models\PelatihanDaftar;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class PesertaController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth'); // authentication
    }

    public function index(){

        $profile = Profile::where('user_id', Auth::user()->id)->first();

        $compact = compact(
            'profile'
        );

        return view('peserta.datadiri', $compact);

    }

    public function post(Request $request) {

        // dapatkan data user
        $user = Auth::User();
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->save(); // update data user firstname dan lastname

        // check apakah user sudah mengisi data diri
        $cek = Profile::where('user_id', Auth::user()->id)->first();

        // jika sudah mengisi data diri maka proses update
        if($cek) {
            $insert = $cek;
        } else { // jika belum mengisi data diri maka proses insert
            $insert = new Profile;
            $insert->psikotest_status = 'Open';
            $insert->buta_warna_status = 'Open';
        }

        $insert->user_id = Auth::user()->id;
        // jika user mengisi inputan photo
        if($request->hasFile('photo')){
            $insert->photo = $request->file('photo')->store('public/files');
        }
        if($request->nama_lengkap){
            $insert->nama_lengkap = $request->nama_lengkap;
        }
        if($request->jenis_kelamin){
            $insert->jenis_kelamin = $request->jenis_kelamin;
        }
        if($request->tempat_lahir){
            $insert->tempat_lahir = $request->tempat_lahir;
        }
        if($request->pendidikan_terakhir){
            $insert->pendidikan_terakhir = $request->pendidikan_terakhir;
        }
        if($request->wa_pribadi){
            $insert->wa_pribadi = $request->wa_pribadi;
        }
        if($request->wa_kerabat){
            $insert->wa_kerabat = $request->wa_kerabat;
        }
        if($request->sekolah_asal){
            $insert->sekolah_asal = $request->sekolah_asal;
        }
        if($request->sumber_info_pelatihan){
            $insert->sumber_info_pelatihan = $request->sumber_info_pelatihan;
        }
        if($request->keterbatasan_fisik){
            $insert->keterbatasan_fisik = $request->keterbatasan_fisik;
        }
        if($request->status_pekerjaan){
            $insert->status_pekerjaan = $request->status_pekerjaan;
        }
        if($request->hasFile('ktp')){
            $insert->ktp = $request->file('ktp')->store('public/files');
        }
        if($request->hasFile('vaksin')){
            $insert->vaksin = $request->file('vaksin')->store('public/files');
        }
        if($request->jurusan) {
            $insert->jurusan = $request->jurusan;
        }
        if($request->alamat) {
            $insert->alamat = $request->alamat;
        }
        if($request->nik) {
            $insert->nik = $request->nik;
        }
        if($request->tanggal_lahir) {
            $insert->tanggal_lahir = $request->tanggal_lahir;
        }

        // data survei
        if($request->tujuan_ikut_pelatihan){
            $insert->tujuan_ikut_pelatihan = $request->tujuan_ikut_pelatihan;
        }
        if($request->sumber_info_ppkd){
            $insert->sumber_info_ppkd = $request->sumber_info_ppkd;
        }
        if($request->sudah_ikut_pelatihan){
            $insert->sudah_ikut_pelatihan = $request->sudah_ikut_pelatihan;
        }
        if($request->siap_ikut_pelatihan){
            $insert->siap_ikut_pelatihan = $request->siap_ikut_pelatihan;
        }
        if($request->usulan_pelatihan){
            $insert->usulan_pelatihan = $request->usulan_pelatihan;
        }
        if($request->pesan_untuk_ppkd){
            $insert->pesan_untuk_ppkd = $request->pesan_untuk_ppkd;
        }

        $insert->save(); // simpan data profile diupdate ataupun diinsert

        return redirect()->back()->with('message', 'Data berhasil disimpan');

    }

    public function testPsikotest() {

        $user = Auth::user();
        $soal = Psikotest::where('status', 'Active')->where('flag', 'Psikotest')->orderBy('nomor_urut')->get();

        $compact = compact(
            'user',
            'soal'
        );

        return view('peserta.testpsikotest', $compact);

    }

    public function testButaWarna() {

        $user = Auth::user();
        $soal = Psikotest::where('status', 'Active')->where('flag', 'Buta Warna')->orderBy('nomor_urut')->get();

        $compact = compact(
            'user',
            'soal'
        );

        return view('peserta.testbutawarna', $compact);

    }

    public function testPsikotestPost(Request $request) {

        // mendapatkan data user login
        $user = Auth::user();
        // mendapatkan data profile user yang login
        $profile = Profile::where('user_id', $user->id)->first();
        // mendapatkan soal psikotest
        $soal = Psikotest::where('status', 'Active')->where('flag', 'Psikotest')->orderBy('nomor_urut', 'asc')->get();
        // setting variable jawabanBenar
        $jawabanBenar = 0;

        // validasi jika jumlah jawaban yang diisi sama dengan jumlah soal
        if(count($request->jawaban) == count($soal)){

            // loop jawaban yang diisi
            foreach($request->jawaban as $index => $j) {

                // hitung jawaban yang benar
                if($soal[$index-1]->jawaban == $j) {
                    // update variable jawabanBenar setiap kali jawaban yang diisi benar
                    $jawabanBenar++;
                }
                
            }

            // mendapatkan nilai
            $nilai = $jawabanBenar / count($soal) * 100; // nilai yang benar dibagi jumlah soal lalu dikalikan 100

            // pembulatan nilai
            $nilaiAkhir = intval(round($nilai)); 

            // simpan hasil test
            $profile->psikotest_score = $nilaiAkhir;
            $profile->psikotest_status = 'Done';
            $profile->save();

            return redirect()->route('test.dasar')->with('message', 'Data Test Berhasil Disimpan');

        } else { // jika jumlah jawaban yang diisi tidak sama dengan jumlah soal

            $messages = [
                'reqired' => 'Harap isi semua soal yang ada',
            ];
            return redirect()->back()->withErrors($messages)->with('error', $messages);

        }

    }

    public function hasilPsikotest() {

        $user = Auth::user();

        $compact = compact(
            'user'
        );

        return view('peserta.hasilPsikotest', $compact);

    }

    public function testButaWarnaPost(Request $request) {

        // mendapatkan data user login
        $user = Auth::user();
        // mendapatkan data profile user yang login
        $profile = Profile::where('user_id', $user->id)->first();
        // mendapatkan soal psikotest
        $soal = Psikotest::where('status', 'Active')->where('flag', 'Buta Warna')->orderBy('nomor_urut', 'asc')->get();
        // setting variable jawabanBenar
        $jawabanBenar = 0;

        // validasi jika jumlah jawaban yang diisi sama dengan jumlah soal
        if(count($request->jawaban) == count($soal)){

            // loop jawaban yang diisi
            foreach($request->jawaban as $index => $j) {

                // hitung jawaban yang benar
                if($soal[$index-1]->jawaban == $j) {
                    // update variable jawabanBenar setiap kali jawaban yang diisi benar
                    $jawabanBenar++;
                }
                
            }

            // mendapatkan nilai
            $nilai = $jawabanBenar / count($soal) * 100; // nilai yang benar dibagi jumlah soal lalu dikalikan 100

            // pembulatan nilai
            $nilaiAkhir = intval(round($nilai));

            // simpan hasil test
            $profile->buta_warna_score = $nilaiAkhir;
            $profile->buta_warna_status = 'Done';
            $profile->save();

            return redirect()->route('test.dasar')->with('message', 'Data Test Berhasil Disimpan');

        } else { // jika jumlah jawaban yang diisi tidak sama dengan jumlah soal

            $messages = [
                'reqired' => 'Harap isi semua soal yang ada',
            ];
            return redirect()->back()->withErrors($messages)->with('error', $messages);

        }

    }

    public function hasilButaWarna() {

        $user = Auth::user();

        $compact = compact(
            'user'
        );

        return view('peserta.hasilButaWarna', $compact);

    }

    public function requestUlang($test) {

        $user = Auth::user();

        // get profile berdasarkan user yang login
        $profile = Profile::where('user_id', $user->id)->first();

        // jika test adalah psikotest
        if($test == 'psikotest') {
            $profile->psikotest_status = 'Request';
        } else if($test == 'buta-warna') { // jika test adalah buta warna
            $profile->buta_warna_status = 'Request';
        } else { // jika test tidak diketahui
            $messages = [
                'reqired' => 'Terjadi kesalahan, proses tidak diketahui',
            ];
            return redirect()->back()->withErrors($messages)->with('error', $messages);
        }

        // update data profile untuk meminta request dibukakan akses mengisi test kembali
        $profile->save();

        return redirect()->route('test.dasar')->with('message', 'Permintaan berhasil dikirim');

    }

    public function adminPeserta() {

        $pelatihan = Pelatihan::where('status', 'New')->limit(4)->get();

        $jurusan = Pelatihan::select('jurusan')->distinct()->limit(4)->get();

        $dataUser = User::where('role', 'Peserta')->get();

        $compact = compact(
            'pelatihan',
            'jurusan',
            'dataUser'
        );

        return view('admin.peserta', $compact);

    }

    public function adminPesertaGrouping($jurusan_pelatihan) {

        $pelatihan = Pelatihan::where('status', 'New')->limit(4)->get();

        $jurusan = Pelatihan::select('jurusan')->distinct()->limit(4)->get();

        $dataUser = DB::table('pelatihan_daftar')
        ->join('users', 'users.id', '=', 'pelatihan_daftar.user_id')
        ->join('profile', 'profile.user_id', '=', 'users.id')
        ->join('pelatihan', 'pelatihan.id', '=', 'pelatihan_daftar.pelatihan_id')
        ->select('users.*', 'pelatihan_daftar.*', 'pelatihan.nama_pelatihan', 'pelatihan.jurusan as pelatihan_jurusan', 'pelatihan.level', 'pelatihan.tanggal_pelatihan_mulai', 'pelatihan.tanggal_pelatihan_selesai', 'profile.*')
        // ->where('pelatihan_daftar.pelatihan_id', $pelatihanId)
        ->where('pelatihan.jurusan', $jurusan_pelatihan)
        ->get();

        $compact = compact(
            'pelatihan',
            'dataUser',
            'jurusan',
            'jurusan_pelatihan'
        );

        return view('admin.pesertaPelatihan', $compact);

    }

    public function changeStatus($userId) {

        $user = User::find($userId);

        if($user->status == 'Active') {
            $user->status = 'Non Active';
        } else {
            $user->status = 'Active';
        }

        $user->save();

        return redirect()->back()->with('message', 'Status berhasil diupdate');

    }

    public function detailNilai($userId) {

        $user = User::find($userId);

        $compact = compact(
            'user'
        );

        return view('admin.detailNilai', $compact);

    }

    public function mintaUlang($userId) {

        $user = User::find($userId);

        $compact = compact(
            'user'
        );

        return view('admin.requestTest', $compact);

    }

    public function decisionRequest($decision, $test, $userId) {

        $user = Profile::where('user_id', $userId)->first();

        if($test == 'psikotest') {
            $user->psikotest_status = 'Open';
        } else {
            $user->buta_warna_status = 'Open';
        }

        $user->save();

        return redirect()->route('peserta.admin')->with('message', 'Status berhasil diupdate');

    }
    
}