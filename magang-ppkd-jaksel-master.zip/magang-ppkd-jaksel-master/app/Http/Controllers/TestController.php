<?php

namespace App\Http\Controllers;

use App\Models\Psikotest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TestController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth'); // authentication
    }

    public function index(){

        $psikotest = Psikotest::where('flag', 'Psikotest')->orderby('nomor_urut', 'asc')->get();

        $data = compact(
            'psikotest'
        );

        return view('admin.psikotest.psikotest', $data);

    }

    public function addPsikotest(){

        $psikotest = Psikotest::where('flag', 'Psikotest')->where('status', 'Active')->orderby('nomor_urut', 'asc')->get();

        $data = compact(
            'psikotest'
        );

        return view('admin.psikotest.psikotest-add', $data);

    }

    public function addPsikotestpost(Request $request) {

        // cek apakah pertanyaan sudah ada atau belum
        $cek = Psikotest::where('flag', 'Psikotest')->where('pertanyaan', $request->pertanyaan)->where('status', 'Active')->first();

        // cek apakah pertanyaan sudah ada atau belum
        $get = Psikotest::where('flag', 'Psikotest')->where('status', 'Active')->get();

        // jika pertanyaan sudah ada
        if(isset($cek)) {
            $messages = [
                'reqired' => 'Pertanyaan sudah ada, silahkan isi yang lain',
            ];
            return redirect()->back()->withErrors($messages)->with('error', $messages);
        } else { // jika pertanyaan belum ada maka insert ke database

            // insert data ke database
            $insert = new Psikotest;
            $insert->flag = 'Psikotest';
            $insert->pertanyaan = $request->pertanyaan;
            if($request->hasFile('pertanyaan-file')){
                $insert->image = $request->file('pertanyaan-file')->store('public/files');
            }
            $insert->option_a = $request->optionA;
            if($request->hasFile('img_a')){
                $insert->img_a = $request->file('img_a')->store('public/files');
            }
            $insert->option_b = $request->optionB;
            if($request->hasFile('img_b')){
                $insert->img_b = $request->file('img_b')->store('public/files');
            }
            $insert->option_c = $request->optionC;
            if($request->hasFile('img_c')){
                $insert->img_c = $request->file('img_c')->store('public/files');
            }
            $insert->option_d = $request->optionD;
            if($request->hasFile('img_d')){
                $insert->img_d = $request->file('img_d')->store('public/files');
            }
            $insert->nomor_urut = $request->nomor_urut;
            $insert->jawaban = $request->jawaban;
            $insert->status = "Active";
            $insert->save();
        }

        return redirect()->route('psikotest')->with('message', 'Data berhasil disimpan!');

    }

    public function moveUp($nomor_urut) {

        // dapatkan data nomor tujuan yang ingin dipindah
        $data = Psikotest::where('flag', 'Psikotest')->where('nomor_urut', $nomor_urut)->first();

        // dapatkan data nomor urut tujuan
        $tujuan = Psikotest::where('flag', 'Psikotest')->where('nomor_urut', $nomor_urut-1)->first();

        // update nomor urut tujuan
        $tujuan->nomor_urut = $data->nomor_urut;
        $tujuan->save();

        // update nomor urut yang ingin dipindah
        $data->nomor_urut = $nomor_urut-1;
        $data->save();

        return redirect()->back()->with('message', 'Nomor urut berhasil dipindah!');

    }

    public function moveDown($nomor_urut) {

        // dapatkan data nomor tujuan yang ingin dipindah
        $data = Psikotest::where('flag', 'Psikotest')->where('nomor_urut', $nomor_urut)->first();

        // dapatkan data nomor urut tujuan
        $tujuan = Psikotest::where('flag', 'Psikotest')->where('nomor_urut', $nomor_urut+1)->first();

        // update nomor urut tujuan
        $tujuan->nomor_urut = $data->nomor_urut;
        $tujuan->save();

        // update nomor urut yang ingin dipindah
        $data->nomor_urut = $nomor_urut+1;
        $data->save();

        return redirect()->back()->with('message', 'Nomor urut berhasil dipindah!');

    }

    public function nonaktif($id) {

        $data = Psikotest::find($id);
        
        // update status
        if($data->status == 'Active') {
            $dataUpdate = Psikotest::where('flag', 'Psikotest')->where('nomor_urut', '>', $data->nomor_urut)->get();
            if($dataUpdate) {

                foreach($dataUpdate as $du){
                    $du->nomor_urut = $du->nomor_urut-1;
                    $du->save();
                }
    
            }

            $data->status = 'Non Active';
            $data->save();
        } else {
            $dataUpdate = Psikotest::where('flag', 'Psikotest')->where('nomor_urut', '>=', $data->nomor_urut)->where('status', 'Active')->get();

            if($dataUpdate) {

                foreach($dataUpdate as $du){
                    $du->nomor_urut = $du->nomor_urut+1;
                    $du->save();
                }
    
            }

            $data->status = 'Active';
            $data->save();
        }

        return redirect()->back()->with('message', 'Status berhasil diupdate!');

    }

    public function delete($id) {

        $data = Psikotest::find($id);
        
        // update nomor urut
        $dataUpdate = Psikotest::where('flag', 'Psikotest')->where('nomor_urut', '>', $data->nomor_urut)->get();
        if($dataUpdate) {

            foreach($dataUpdate as $du){
                $du->nomor_urut = $du->nomor_urut-1;
                $du->save();
            }

        }

        $data->delete();

        return redirect()->back()->with('message', 'Data berhasil dihapus!');

    }

    public function edit($id){

        $data = Psikotest::find($id);
        $psikotest = Psikotest::where('flag', 'Psikotest')->where('status', 'Active')->orderby('nomor_urut', 'asc')->get();

        $compact = compact(
            'data',
            'psikotest'
        );

        return view('admin.psikotest.psikotest-edit', $compact);

    }

    public function editPsikotestPost($id, Request $request) {

        // get data psikotest berdasarkan id
        $data = Psikotest::find($id);

        // update data psikotest
        $data->pertanyaan = $request->pertanyaan;
        if($request->hasFile('pertanyaan-file')){
            $data->image = $request->file('pertanyaan-file')->store('public/files');
        }
        $data->option_a = $request->optionA;
        if($request->hasFile('img_a')){
            $data->img_a = $request->file('img_a')->store('public/files');
        }
        $data->option_b = $request->optionB;
        if($request->hasFile('img_b')){
            $data->img_b = $request->file('img_b')->store('public/files');
        }
        $data->option_c = $request->optionC;
        if($request->hasFile('img_c')){
            $data->img_c = $request->file('img_c')->store('public/files');
        }
        $data->option_d = $request->optionD;
        if($request->hasFile('img_d')){
            $data->img_d = $request->file('img_d')->store('public/files');
        }
        $data->jawaban = $request->jawaban;
        $data->save();

        return redirect()->route('psikotest')->with('message', 'Data berhasil diupdate!');

    }

    public function testDasar() {

        $user = Auth::user();

        if($user->profile){
            return view('peserta.testdasar');
        } else {
            $messages = [
                'reqired' => 'Anda harus melengkapi data diri terlebih dahulu!',
            ];
            return redirect()->back()->withErrors($messages)->with('error', $messages);
        }


    }
}