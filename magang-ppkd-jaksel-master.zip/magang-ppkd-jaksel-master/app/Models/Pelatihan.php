<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pelatihan extends Model
{
    use HasFactory;

    protected $table = 'pelatihan';

    public function getListDaftar() {

        return $this->hasMany('App\Models\PelatihanDaftar', 'pelatihan_id', 'id');

    }
}
