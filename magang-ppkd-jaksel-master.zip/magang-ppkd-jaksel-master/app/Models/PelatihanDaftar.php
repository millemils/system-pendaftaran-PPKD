<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PelatihanDaftar extends Model
{
    use HasFactory;

    protected $table = 'pelatihan_daftar';

    public function getPelatihan() {

        return $this->hasOne('App\Models\Pelatihan', 'id', 'pelatihan_id');

    }

    public function getUser() {

        return $this->hasOne('App\Models\User', 'id', 'user_id');

    }

    public function getProfile() {

        return $this->hasOne('App\Models\Profile', 'user_id', 'user_id');

    }
}
